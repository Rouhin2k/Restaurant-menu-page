// Array of menu items, each item has a name, category, price, and image URL
const menuItems = [
  { name: 'Caesar Salad', category: 'appetizers', price: 5.99, img: 'https://i.postimg.cc/1RJj3YpY/the-best-caesar-salad-recipe-06-40e70f549ba2489db09355abd62f79a9.jpg' },
  { name: 'Spaghetti Bolognese', category: 'main-course', price: 12.99, img: 'https://i.postimg.cc/T1pqwQ6Z/images.jpg' },
  { name: 'Cheesecake', category: 'desserts', price: 6.99, img: 'https://i.postimg.cc/3rstL4HY/cheesecake-senza-burro.jpg' },
  { name: 'Grilled Chicken', category: 'main-course', price: 14.99, img: 'https://i.postimg.cc/V5ym7jj3/Grilled-Balsamic-Chicken-2.jpg' },
  { name: 'Mughlai egg chicken', category: 'main-course', price: 4.99, img: 'https://i.postimg.cc/t4H0cqKq/Mughlai-Chicken-Recipe-1.jpg' },
  { name: 'Mojito', category: 'beverages', price: 5.99, img: 'https://i.postimg.cc/sgR8DVsP/Mojito-FT-RECIPE1022-2000-85cdb1eb59454847b713713e32e365c0.jpg' },
  { name: 'Chocolate Cake', category: 'desserts', price: 7.99, img: 'https://i.postimg.cc/GmQMLGMr/chocolate-cake-index-64b83bce2df26.jpg' },
  { name: 'Bruschetta', category: 'appetizers', price: 4.99, img: 'https://i.postimg.cc/qRnyRdkn/Bruschetta-recipe-with-mozzarella-2.jpg' },
  { name: 'Butter Chicken', category: 'main-course', price: 11.99, img: 'https://i.postimg.cc/zDLyk7wC/butter-chicken-ac2ff98.jpg' },
  { name: 'Paneer Tikka', category: 'appetizers', price: 8.99, img: 'https://i.postimg.cc/3rDwGR79/Paneer-Tikka-Masala-Recipe-1.jpg' },
  { name: 'Gulab Jamun', category: 'desserts', price: 4.99, img: 'https://i.postimg.cc/NjbGt27G/milk-powder-gulab-jamuns.jpg' },
  { name: 'Laccha Paratha', category: 'main-course', price: 1.99, img: 'https://i.postimg.cc/0yJQYyp9/Paratha.jpg' },
  { name: 'Biryani', category: 'main-course', price: 10.99, img: 'https://i.postimg.cc/Dz8hKjw5/dum-chicken-biriyani-close-image-600nw-2445682315.webp' },
  { name: 'Plain Naan', category: 'main-course', price: 1.99, img: 'https://i.postimg.cc/cJ8zmVHq/Super-Naan-e1547564707993.jpg' },
  { name: 'Garlic Naan', category: 'main-course', price: 2.49, img: 'https://i.postimg.cc/bwQ7QZ3F/Garlic-Naan.webp' },
  { name: 'Mixed Rice', category: 'main-course', price: 2.99, img: 'https://i.postimg.cc/MKywY3GD/Vegetable-Fried-Rice-2-3-500x500.jpg' },
  { name: 'Kashmiri Pulao', category: 'main-course', price: 9.99, img: 'https://i.postimg.cc/N0yKm1pH/Kashmiri-pulao-recipe-Kashmiri-biryani-Dry-fruits-biryani-Kashmiri-rice-pilaf-recipe-by-sagar-kitche.webp' },
  { name: 'Kashmiri Aloo Dum', category: 'main-course', price: 8.99, img: 'https://i.postimg.cc/NFxFBbfW/Kashmiri-Style-Dum-Oluv-Recipe-Whole-Spicy-Baby-Potatoes-Recipes.jpg' },
  { name: 'Indian Sea Fish Curry', category: 'main-course', price: 13.99, img: 'https://i.postimg.cc/vH3TKPKn/fish.webp' },
  { name: 'Mutton Rogan Josh', category: 'main-course', price: 15.99, img: 'https://i.postimg.cc/BQQQ2Tvn/Rogan-Josh-2-Picture-The-Recipe.jpg' }
];

// Object holding conversion rates for different currencies
const currencyRates = {
  USD: 1,
  INR: 83,
  EUR: 0.92
};

// Variable to keep track of the currently selected currency
let currentCurrency = 'USD';

// Function to display the menu items on the page
function displayMenu(items) {
  // Get the menu container element by its ID
  const menu = document.getElementById('menu');
  // Clear any existing content in the menu container
  menu.innerHTML = '';
  // Loop through each item in the items array
  items.forEach(item => {
    // Create a new div element for the menu item
    const menuItem = document.createElement('div');
    // Add the 'menu-item' class to the new div
    menuItem.className = 'menu-item';
    // Set the inner HTML of the new div to include the item image, name, category, and price
    menuItem.innerHTML = `
      <img src="${item.img}" alt="${item.name}">
      <h2>${item.name}</h2>
      <p class="category">${item.category}</p>
      <p class="price">${convertPrice(item.price)} ${currentCurrency}</p>
    `;
    // Append the new div to the menu container
    menu.appendChild(menuItem);
  });
}

// Function to filter the menu items based on the selected category
function filterMenu() {
  // Get the selected category from the dropdown
  const category = document.getElementById('category').value;
  // Filter the menu items based on the selected category
  const filteredItems = category === 'all' ? menuItems : menuItems.filter(item => item.category === category);
  // Display the filtered items
  displayMenu(filteredItems);
}

// Function to sort the menu items based on the selected criteria (name or price)
function sortMenu() {
  // Get the selected sort criteria from the dropdown
  const sortBy = document.getElementById('sort').value;
  // Sort the items array based on the selected criteria
  const sortedItems = [...menuItems].sort((a, b) => {
    if (sortBy === 'name') {
      return a.name.localeCompare(b.name);
    } else if (sortBy === 'price') {
      return a.price - b.price;
    }
  });
  // Display the sorted items
  displayMenu(sortedItems);
}

// Function to convert the price based on the selected currency
function convertPrice(price) {
  // Convert the price using the current currency rate and return the converted price
  return (price * currencyRates[currentCurrency]).toFixed(2);
}

// Function to handle currency conversion when a new currency is selected
function convertCurrency() {
  // Get the selected currency from the dropdown
  currentCurrency = document.getElementById('currency').value;
  // Redisplay the menu items with the new currency conversion
  displayMenu(menuItems);
}

// Event listener to display the menu items when the DOM content is loaded
document.addEventListener('DOMContentLoaded', () => {
  displayMenu(menuItems);
});
